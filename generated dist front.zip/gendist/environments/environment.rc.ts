export const environment = {
  production: true,
  environmentName: 'rc',
  apiUrl: '/api'
};
