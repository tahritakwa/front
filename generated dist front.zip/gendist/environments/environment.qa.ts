export const environment = {
    production: true,
    environmentName: 'qa',
    apiUrl: '/api'
};