export const environment = {
  production: true,
  environmentName: 'itg',
  apiUrl: '/api'
};
