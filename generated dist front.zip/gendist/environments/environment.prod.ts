export const environment = {
  production: true,
  environmentName: 'prod',
  apiUrl: '/api'
};
